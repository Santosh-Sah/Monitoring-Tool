using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace SystemMonitor
{
	/// <summary>
	/// Summary description for ConnectionWizard.
	/// </summary>
	public class ConnectionWizard : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button connectButton;
		private System.Windows.Forms.Button cancelButton;
		private System.Windows.Forms.TextBox password;
		private System.Windows.Forms.TextBox username;
		private System.Windows.Forms.TextBox ipaddress;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ConnectionWizard()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			strUsername = "";
			strPassword = "";
			strIpaddress = "127.0.0.1";
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.connectButton = new System.Windows.Forms.Button();
			this.cancelButton = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.password = new System.Windows.Forms.TextBox();
			this.username = new System.Windows.Forms.TextBox();
			this.ipaddress = new System.Windows.Forms.TextBox();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// connectButton
			// 
			this.connectButton.Location = new System.Drawing.Point(40, 136);
			this.connectButton.Name = "connectButton";
			this.connectButton.Size = new System.Drawing.Size(88, 24);
			this.connectButton.TabIndex = 0;
			this.connectButton.Text = "Connect";
			this.connectButton.Click += new System.EventHandler(this.connectButton_Click);
			// 
			// cancelButton
			// 
			this.cancelButton.Location = new System.Drawing.Point(168, 136);
			this.cancelButton.Name = "cancelButton";
			this.cancelButton.Size = new System.Drawing.Size(88, 24);
			this.cancelButton.TabIndex = 1;
			this.cancelButton.Text = "Cancel";
			this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.password);
			this.groupBox1.Controls.Add(this.username);
			this.groupBox1.Controls.Add(this.ipaddress);
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(280, 112);
			this.groupBox1.TabIndex = 5;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Connection Information";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 72);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(96, 16);
			this.label3.TabIndex = 14;
			this.label3.Text = "Password:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(96, 16);
			this.label2.TabIndex = 13;
			this.label2.Text = "Username:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 16);
			this.label1.TabIndex = 12;
			this.label1.Text = "IP Address:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// password
			// 
			this.password.Location = new System.Drawing.Point(120, 72);
			this.password.Name = "password";
			this.password.Size = new System.Drawing.Size(144, 20);
			this.password.TabIndex = 11;
			this.password.Text = "";
			// 
			// username
			// 
			this.username.Location = new System.Drawing.Point(120, 48);
			this.username.Name = "username";
			this.username.Size = new System.Drawing.Size(144, 20);
			this.username.TabIndex = 10;
			this.username.Text = "";
			// 
			// ipaddress
			// 
			this.ipaddress.Location = new System.Drawing.Point(120, 24);
			this.ipaddress.Name = "ipaddress";
			this.ipaddress.Size = new System.Drawing.Size(144, 20);
			this.ipaddress.TabIndex = 9;
			this.ipaddress.Text = "127.0.0.1";
			// 
			// ConnectionWizard
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(296, 165);
			this.ControlBox = false;
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.cancelButton);
			this.Controls.Add(this.connectButton);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ConnectionWizard";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "ConnectionWizard";
			this.Load += new System.EventHandler(this.ConnectionWizard_Load);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		public String strIpaddress;
		public String strUsername;
		public String strPassword;

		private void cancelButton_Click(object sender, System.EventArgs e)
		{
			// Return a Cancel status and close the form.
			this.DialogResult = DialogResult.Cancel;
			this.Close();
		}

		private void connectButton_Click(object sender, System.EventArgs e)
		{
			// Return an Ok status and close the form. The values entered can
			// be gotten from the public variables.
			this.DialogResult = DialogResult.OK;
			strIpaddress = ipaddress.Text;
			strUsername = username.Text;
			strPassword = password.Text;
			this.Close();
		}

		private void ConnectionWizard_Load(object sender, System.EventArgs e)
		{
			// Load the default values that are assigned to these variables.
			ipaddress.Text = strIpaddress;
			username.Text = strUsername;
			password.Text = strPassword;
		}
	}
}
